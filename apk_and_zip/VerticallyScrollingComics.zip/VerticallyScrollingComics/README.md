Contributors: Joe C. Bernstein, Ethan Coates, Matthew Island, and Meehan Imam

Website: https://jewjojo.github.io/VerticallyScrollingComics/index.html
