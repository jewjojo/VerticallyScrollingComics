package com.umdproject.verticallyscrollingcomics.viewModels

class LocalComicsViewModel {
}