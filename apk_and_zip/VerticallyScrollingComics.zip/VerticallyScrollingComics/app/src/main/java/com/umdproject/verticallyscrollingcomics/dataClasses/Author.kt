package com.umdproject.verticallyscrollingcomics.dataClasses

data class Author (val authorUid: String ="", val authorName: String = "", val authorCountry: String = "")